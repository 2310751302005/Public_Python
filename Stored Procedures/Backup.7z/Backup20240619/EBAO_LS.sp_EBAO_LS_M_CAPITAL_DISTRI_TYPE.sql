USE [SELIC]
GO

/****** Object:  StoredProcedure [dbo].[spInsert_M_CAPITAL_DISTRI_TYPE]    Script Date: 19/6/2567 11:55:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spInsert_M_CAPITAL_DISTRI_TYPE] 
	-- Add the parameters for the stored procedure here
	@o_output int output
AS
BEGIN
	BEGIN TRY -------------------- BEGIN TRY
	 DECLARE @error_message nvarchar(max)

	-- Declare variables
		DECLARE @modifier VARCHAR(50);
		SET @modifier = 'ITDM\TANASUP'

--DELETE BY DISTRI_TYPE(Key)
	DELETE FROM  [SELIC].[EBAO_LS].[M_CAPITAL_DISTRI_TYPE] 
	WHERE [DISTRI_TYPE] IN (SELECT [DISTRI_TYPE] FROM [SELIC_STAGING].[EBAO_LS].[STG_T_CAPITAL_DISTRI_TYPE])


	INSERT INTO [SELIC].[EBAO_LS].[M_CAPITAL_DISTRI_TYPE] ([DISTRI_TYPE]
      ,[TYPE_NAME]
      ,[DISTRI_TYPE_CODE]
      ,[DISTRI_TYPE_DESC]
      ,[CAPITAL_DESC]
      ,[FUND_DESC]
      ,[CAPITAL_POST_GL]
      ,[FUND_POST_GL]
      ,[BIZ_RELATED]
      ,[FIN_RELATED]
      ,[CAPITAL_DISTRI_OWNED]
      ,[FUND_CASH_OWNED]
      ,[AR_AP]
      ,[ODS_CREATED_DATE]
      ,[ODS_CREATED_BY]
      ,[ODS_MODIFIED_DATE]
      ,[ODS_MODIFIED_BY]
		  )

	SELECT [DISTRI_TYPE]
		  ,[TYPE_NAME]
		  ,[DISTRI_TYPE_CODE]
		  ,[DISTRI_TYPE_DESC]
		  ,[CAPITAL_DESC]
		  ,[FUND_DESC]
		  ,[CAPITAL_POST_GL]
		  ,[FUND_POST_GL]
		  ,[BIZ_RELATED]
		  ,[FIN_RELATED]
		  ,[CAPITAL_DISTRI_OWNED]
		  ,[FUND_CASH_OWNED]
		  ,[AR_AP]
		  ,GETDATE() AS [ODS_CREATED_DATE]
		  ,@modifier AS [ODS_CREATED_BY]
		  ,GETDATE() AS [ODS_MODIFIED_DATE]
		  ,@modifier AS [ODS_MODIFIED_BY]
	  FROM [SELIC_STAGING].[EBAO_LS].[STG_T_CAPITAL_DISTRI_TYPE]
--	  where (SUBSTRING([FILE_NAME],(PATINDEX('%[0-9]%',[FILE_NAME])),8) = @latest_file_date)
--			and DOC_NBR Not Like '%Total%'


	END TRY  -------------------- END TRY
	BEGIN CATCH  
		SET @error_message = (SELECT ERROR_MESSAGE())
		SET @o_output = 1
		SELECT @error_message AS ERROR
	END CATCH  -------------------- END CATCH
END
GO

