USE [SELIC]
GO

/****** Object:  StoredProcedure [EBAO_LS].[sp_EBAO_LS_M_FEE_TYPE]    Script Date: 19/6/2567 13:54:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [EBAO_LS].[sp_EBAO_LS_M_FEE_TYPE] 
	-- Add the parameters for the stored procedure here
	@o_output int output
AS
BEGIN
	BEGIN TRY -------------------- BEGIN TRY
	 DECLARE @error_message nvarchar(max)

	-- Declare variables
		DECLARE @modifier VARCHAR(50);
		SET @modifier = 'ITDM\TANASUP'

--DELETE BY DISTRI_TYPE(Key)
	DELETE FROM  [SELIC].[EBAO_LS].[M_FEE_TYPE]
	WHERE EXISTS (SELECT 1 
	FROM [SELIC_STAGING].[EBAO_LS].[STG_M_FEE_TYPE] stg
	where stg.[FEE_TYPE_ID] = [FEE_TYPE_ID])


	INSERT INTO [SELIC].[EBAO_LS].[M_FEE_TYPE] (
				[FEE_TYPE_ID],
				[FEE_TYPE_NAME],
				[COMMISSION],
				[DATA_TABLE],
				[AR_AP_FLAG],
				[CASH_IN_OUT],
				[POST_TO_GL],
				[TYPE_DESC],
				[ARAP_LEVEL],
				[ODS_CREATED_DATE],
				[ODS_CREATED_BY]
				)

	SELECT [FEE_TYPE_ID]
		  ,[FEE_TYPE_NAME]
		  ,[COMMISSION]
		  ,[DATA_TABLE]
		  ,[AR_AP_FLAG]
		  ,[CASH_IN_OUT]
		  ,[POST_TO_GL]
		  ,[TYPE_DESC]
		  ,[ARAP_LEVEL]
		  ,GETDATE() AS [ODS_CREATED_DATE]
		  ,@modifier AS [ODS_CREATED_BY]
	  FROM [SELIC_STAGING].[EBAO_LS].[STG_M_FEE_TYPE]
--	  where (SUBSTRING([FILE_NAME],(PATINDEX('%[0-9]%',[FILE_NAME])),8) = @latest_file_date)
--			and DOC_NBR Not Like '%Total%'


	END TRY  -------------------- END TRY
	BEGIN CATCH  
		SET @error_message = (SELECT ERROR_MESSAGE())
		SET @o_output = 1
		SELECT @error_message AS ERROR
	END CATCH  -------------------- END CATCH
END
GO

