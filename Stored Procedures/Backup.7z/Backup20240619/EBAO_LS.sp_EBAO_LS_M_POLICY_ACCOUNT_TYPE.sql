USE [SELIC]
GO

/****** Object:  StoredProcedure [EBAO_LS].[sp_EBAO_LS_M_POLICY_ACCOUNT_TYPE]    Script Date: 19/6/2567 14:55:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [EBAO_LS].[sp_EBAO_LS_M_POLICY_ACCOUNT_TYPE] 
	-- Add the parameters for the stored procedure here
	@o_output int output
AS
BEGIN
	BEGIN TRY -------------------- BEGIN TRY
	 DECLARE @error_message nvarchar(max)

	-- Declare variables
		DECLARE @modifier VARCHAR(50);
		SET @modifier = 'ITDM\TANASUP'

--DELETE BY DISTRI_TYPE(Key)
	DELETE FROM  [SELIC].[EBAO_LS].[M_POLICY_ACCOUNT_TYPE]
	WHERE EXISTS (SELECT 1 
	FROM [SELIC_STAGING].[EBAO_LS].[STG_T_POLICY_ACCOUNT_TYPE] stg
	where stg.[ACCOUNT_TYPE] = [ACCOUNT_TYPE])


	INSERT INTO [SELIC].[EBAO_LS].[M_POLICY_ACCOUNT_TYPE] (
				[ACCOUNT_TYPE],
				[ACCOUNT_NAME],
				[RATE_TYPE],
				[MAIN_TYPE],
				[MGMT_TYPE],
				[FIRST_DEDUCT_FROM],
				[MULTIPLE_ACCOUNT_ORDER],
				[INTEREST_CALCULATION_TYPE],
				[CAPITALIZATION_FREQUENCY],
				[CAPITALIZATION_DUE_TYPE],
				[INTEREST_FREQUENCY],
				[INTEREST_DUE_TYPE],
				[ODS_CREATED_DATE],
				[ODS_CREATED_BY],
				[ODS_MODIFIED_DATE],
				[ODS_MODIFIED_BY]
				)

	SELECT [ACCOUNT_TYPE]
		  ,[ACCOUNT_NAME]
		  ,[RATE_TYPE]
		  ,[MAIN_TYPE]
		  ,[MGMT_TYPE]
		  ,[FIRST_DEDUCT_FROM]
		  ,[MULTIPLE_ACCOUNT_ORDER]
		  ,[INTEREST_CALCULATION_TYPE]
		  ,[CAPITALIZATION_FREQUENCY]
		  ,[CAPITALIZATION_DUE_TYPE]
		  ,[INTEREST_FREQUENCY]
		  ,[INTEREST_DUE_TYPE]
		  ,GETDATE() AS [ODS_CREATED_DATE]
		  ,@modifier AS [ODS_CREATED_BY]
		  ,GETDATE() AS [ODS_MODIFIED_DATE]
		  ,@modifier AS [ODS_MODIFIED_BY]
	  FROM [SELIC_STAGING].[EBAO_LS].[STG_T_POLICY_ACCOUNT_TYPE]
--	  where (SUBSTRING([FILE_NAME],(PATINDEX('%[0-9]%',[FILE_NAME])),8) = @latest_file_date)
--			and DOC_NBR Not Like '%Total%'


	END TRY  -------------------- END TRY
	BEGIN CATCH  
		SET @error_message = (SELECT ERROR_MESSAGE())
		SET @o_output = 1
		SELECT @error_message AS ERROR
	END CATCH  -------------------- END CATCH
END
GO

