USE [SELIC]
GO

/****** Object:  StoredProcedure [EBAO_LS].[sp_EBAO_LS_T_CLAIM_ADJUST]    Script Date: 20/6/2567 10:21:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [EBAO_LS].[sp_EBAO_LS_T_CLAIM_ADJUST] 
	-- Add the parameters for the stored procedure here
	@o_output int output
AS
BEGIN
	BEGIN TRY -------------------- BEGIN TRY
	 DECLARE @error_message nvarchar(max)

	-- Declare variables
		DECLARE @modifier VARCHAR(50);
		SET @modifier = 'ITDM\TANASUP'

--DELETE BY DISTRI_TYPE(Key)
	DELETE FROM  [SELIC].[EBAO_LS].[CLAIM_ADJUST]
	WHERE EXISTS (SELECT 1 
	FROM [SELIC_STAGING].[EBAO_LS].[STG_CLAIM_ADJUST] stg
	where stg.[CLAIM_ADJUST_ID] = [CLAIM_ADJUST_ID])


	INSERT INTO [SELIC].[EBAO_LS].[CLAIM_ADJUST](
				[CLAIM_ADJUST_ID]
				,[CASE_ID]
				,[INSURED_ID]
				,[FEE_AMOUNT]
				,[CURRENCY_ID]
				,[CURRENCY_CODE]
				,[ORIG_CURRENCY_ID]
				,[FEE_TYPE_ID]
				,[FEE_TYPE_NAME]
				,[POLICY_ID]
				,[PRODUCT_ID]
				,[PRODUCT_NAME]
				,[ITEM_ID]
				,[PREMIUM_ARAP_ID]
				,[ADJUSTMENT_AMOUNT]
				,[PAYMENT_AMOUNT]
				,[RECORDER_ID]
				,[RECORDER_NAME]
				,[UPDATER_ID]
				,[UPDATER_NAME]
				,[OPERATION_SIGN]
				,[CLAIM_PAYMENT_ID]
				,[CLAIM_ADJUST_TYPE_ID]
				,[CLAIM_ADJUST_TYPE_DESC]
				,[ADVANCE_PAYMENT_INDIVIDUAL]
				,[INSERTED_BY]
				,[INSERTED_NAME]
				,[UPDATED_BY]
				,[UPDATED_NAME]
				,[INSERT_TIME]
				,[UPDATE_TIME]
				,[INSERTED_TIMESTAMP]
				,[UPDATED_TIMESTAMP]
				,[REMARKS]
				,[ODS_CREATED_DATE]
				,[ODS_CREATED_BY]
				,[ODS_MODIFIED_DATE]
				,[ODS_MODIFIED_BY]
				)

	SELECT	[CLAIM_ADJUST_ID]
			,[CASE_ID]
			,[INSURED_ID]
			,[FEE_AMOUNT]
			,[CURRENCY_ID]
			,[CURRENCY_CODE]
			,[ORIG_CURRENCY_ID]
			,[FEE_TYPE_ID]
			,[FEE_TYPE_NAME]
			,[POLICY_ID]
			,[PRODUCT_ID]
			,[PRODUCT_NAME]
			,[ITEM_ID]
			,[PREMIUM_ARAP_ID]
			,[ADJUSTMENT_AMOUNT]
			,[PAYMENT_AMOUNT]
			,[RECORDER_ID]
			,[RECORDER_NAME]
			,[UPDATER_ID]
			,[UPDATER_NAME]
			,[OPERATION_SIGN]
			,[CLAIM_PAYMENT_ID]
			,[CLAIM_ADJUST_TYPE_ID]
			,[CLAIM_ADJUST_TYPE_DESC]
			,[ADVANCE_PAYMENT_INDIVIDUAL]
			,[INSERTED_BY]
			,[INSERTED_NAME]
			,[UPDATED_BY]
			,[UPDATED_NAME]
			,[INSERT_TIME]
			,[UPDATE_TIME]
			,[INSERTED_TIMESTAMP]
			,[UPDATED_TIMESTAMP]
			,[REMARKS]
		  ,GETDATE() AS [ODS_CREATED_DATE]
		  ,@modifier AS [ODS_CREATED_BY]
		  ,GETDATE() AS [ODS_MODIFIED_DATE]
		  ,@modifier AS [ODS_MODIFIED_BY]
	  FROM [SELIC_STAGING].[EBAO_LS].[STG_CLAIM_ADJUST]
--	  where (SUBSTRING([FILE_NAME],(PATINDEX('%[0-9]%',[FILE_NAME])),8) = @latest_file_date)
--			and DOC_NBR Not Like '%Total%'


	END TRY  -------------------- END TRY
	BEGIN CATCH  
		SET @error_message = (SELECT ERROR_MESSAGE())
		SET @o_output = 1
		SELECT @error_message AS ERROR
	END CATCH  -------------------- END CATCH
END
GO

