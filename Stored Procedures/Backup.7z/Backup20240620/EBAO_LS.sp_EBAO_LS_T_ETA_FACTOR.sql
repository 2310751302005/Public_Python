USE [SELIC]
GO

/****** Object:  StoredProcedure [EBAO_LS].[sp_EBAO_LS_T_ETA_FACTOR]    Script Date: 20/6/2567 14:03:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







---- =============================================
---- Author:		<Kannikar P.>
---- Create date:	<19-06-2024>
---- Description:	<EBAO LS ETA_FACTOR>
---- =============================================
CREATE PROCEDURE [EBAO_LS].[sp_EBAO_LS_T_ETA_FACTOR]
	@o_output int output
AS
BEGIN

BEGIN TRY -------------------- BEGIN TRY

	DECLARE @error_message NVARCHAR(MAX);

	DECLARE @modifier VARCHAR(50);
	SET @modifier = 'ITDM\KANNIKAR'


	DELETE FROM [EBAO_LS].[ETA_FACTOR]
	WHERE EXISTS (SELECT 1 
				  FROM [SELIC_STAGING].[EBAO_LS].[STG_ETA_FACTOR] eta
				  WHERE eta.[GENDER_CODE] = [GENDER_CODE]
				  AND eta.[AGE] = [AGE]
				  AND eta.[ORGANIZATION_ID] = [ORGANIZATION_ID]
				  AND eta.[TMO_VERSION] = [TMO_VERSION]
				  AND eta.[INTEREST_RATE] = [INTEREST_RATE]
				  AND eta.[ETI_LOADING_RATE] = [ETI_LOADING_RATE])


	INSERT INTO [EBAO_LS].[ETA_FACTOR]
		([GENDER_CODE], [GENDER_DESC], [AGE], [ORGANIZATION_ID], [ORGANIZATION_NAME], [TMO_VERSION], [INTEREST_RATE], [ETI_LOADING_RATE], [M_FACTOR], [D_FACTOR], [ODS_CREATED_DATE], [ODS_CREATED_BY], [ODS_MODIFIED_DATE], [ODS_MODIFIED_BY])
	SELECT 
		 [GENDER_CODE], [GENDER_DESC], [AGE], [ORGANIZATION_ID], [ORGANIZATION_NAME], [TMO_VERSION], [INTEREST_RATE], [ETI_LOADING_RATE], [M_FACTOR], [D_FACTOR], GETDATE(), @modifier, GETDATE(), @modifier
	FROM [SELIC_STAGING].[EBAO_LS].[STG_ETA_FACTOR]


END TRY  -------------------- END TRY
BEGIN CATCH  
	SET @error_message = (SELECT ERROR_MESSAGE())
	SET @o_output = 1
	SELECT @error_message AS ERROR
END CATCH  -------------------- END CATCH

END

GO

