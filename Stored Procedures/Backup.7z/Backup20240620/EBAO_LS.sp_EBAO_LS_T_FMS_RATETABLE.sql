USE [SELIC]
GO

/****** Object:  StoredProcedure [EBAO_LS].[sp_EBAO_LS_T_FMS_RATETABLE]    Script Date: 20/6/2567 14:02:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







---- =============================================
---- Author:		<Kannikar P.>
---- Create date:	<20-06-2024>
---- Description:	<EBAO LS T_FMS_RATETABLE>
---- =============================================
CREATE PROCEDURE [EBAO_LS].[sp_EBAO_LS_T_FMS_RATETABLE]
	@o_output int output
AS
BEGIN

BEGIN TRY -------------------- BEGIN TRY

	DECLARE @error_message NVARCHAR(MAX);

	DECLARE @modifier VARCHAR(50);
	SET @modifier = 'ITDM\KANNIKAR'


	DELETE FROM [EBAO_LS].[T_FMS_RATETABLE]
	WHERE EXISTS (SELECT 1 
				  FROM [SELIC_STAGING].[EBAO_LS].[STG_T_FMS_RATETABLE] r
				  WHERE r.[RATETABLE_ID] = [RATETABLE_ID])


	INSERT INTO [EBAO_LS].[T_FMS_RATETABLE]
		([COLUMN_VALUE], [RESULT_VALUE_1], [RESULT_VALUE_2], [RESULT_VALUE_3], [RESULT_VALUE_4], [RESULT_VALUE_5], [RESULT_VALUE_6], [RESULT_VALUE_7], [RESULT_VALUE_8], [RESULT_VALUE_9], [RESULT_VALUE_10], [RATETABLE_ID], [ODS_CREATED_DATE], [ODS_CREATED_BY], [ODS_MODIFIED_DATE], [ODS_MODIFIED_BY])
	SELECT 
		 [COLUMN_VALUE], [RESULT_VALUE_1], [RESULT_VALUE_2], [RESULT_VALUE_3], [RESULT_VALUE_4], [RESULT_VALUE_5], [RESULT_VALUE_6], [RESULT_VALUE_7], [RESULT_VALUE_8], [RESULT_VALUE_9], [RESULT_VALUE_10], [RATETABLE_ID], GETDATE(), @modifier, GETDATE(), @modifier
	FROM [SELIC_STAGING].[EBAO_LS].[STG_T_FMS_RATETABLE]


END TRY  -------------------- END TRY
BEGIN CATCH  
	SET @error_message = (SELECT ERROR_MESSAGE())
	SET @o_output = 1
	SELECT @error_message AS ERROR
END CATCH  -------------------- END CATCH

END

GO

