USE [SELIC]
GO

/****** Object:  StoredProcedure [EBAO_LS].[sp_EBAO_LS_T_CAPITAL_DISTRIBUTE]    Script Date: 20/6/2567 14:09:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [EBAO_LS].[sp_EBAO_LS_T_CAPITAL_DISTRIBUTE] 
	-- Add the parameters for the stored procedure here
	@o_output int output
AS
BEGIN
	BEGIN TRY -------------------- BEGIN TRY
	 DECLARE @error_message nvarchar(max)

	-- Declare variables
		DECLARE @modifier VARCHAR(50);
		SET @modifier = 'ITDM\TANASUP'

IF EXISTS (SELECT * FROM [SELIC_STAGING].[EBAO_LS].[STG_CAPITAL_DISTRIBUTE])
BEGIN
--DELETE BY DISTRI_TYPE(Key)
	DELETE FROM  [SELIC].[EBAO_LS].[CAPITAL_DISTRIBUTE]
	WHERE EXISTS (SELECT 1 
	FROM [SELIC_STAGING].[EBAO_LS].[STG_CAPITAL_DISTRIBUTE] stg
	where stg.[CAPITAL_DISTRIBUTE_ID] = [CAPITAL_DISTRIBUTE_ID])


	INSERT INTO [SELIC].[EBAO_LS].[CAPITAL_DISTRIBUTE](
			[CAPITAL_DISTRIBUTE_ID]
			,[DISTRIBUTE_DATE]
			,[ITEM_ID]
			,[POLICY_ID]
			,[INSURED_ID]
			,[PRODUCT_ID]
			,[PRODUCT_NAME]
			,[DISTRIBUTE_AMOUNT]
			,[POSTED]
			,[INSERT_TIME]
			,[UPDATE_TIME]
			,[PREMIUM_ID]
			,[REALLOCATED]
			,[DISTRIBUTE_TYPE]
			,[CAPITAL_SOURCE]
			,[CAPITAL_CHANGE_ID]
			,[BONUS_ALLOCATION_METHOD]
			,[BONUS_SUM_ASSURED]
			,[ORIGIN_AMOUNT]
			,[ORIGIN_BONUS_SUM_ASSURED]
			,[CURRENCY_ID]
			,[CURRENCY_CODE]
			,[ORIG_CURRENCY_ID]
			,[CHARGE_TYPE_ID]
			,[CHARGE_TYPE_NAME]
			,[REVERSAL_ID]
			,[RELATED_ID]
			,[ACCOUNTING_DATE]
			,[JE_CREATOR_ID]
			,[JE_CREATOR__NAME]
			,[JE_POSTING_ID]
			,[DR_SEG1]
			,[DR_SEG2]
			,[DR_SEG3]
			,[DR_SEG4]
			,[DR_SEG6]
			,[DR_SEG7]
			,[DR_SEG8]
			,[CR_SEG1]
			,[CR_SEG2]
			,[CR_SEG3]
			,[CR_SEG4]
			,[CR_SEG6]
			,[CR_SEG7]
			,[CR_SEG8]
			,[ORGANIZATION_ID]
			,[AGENT_ID]
			,[ACCOUNT_TYPE_CODE]
			,[ACCOUNT_TYPE_NAME]
			,[INSERTED_BY]
			,[INSERTED_NAME]
			,[INSERT_TIMESTAMP]
			,[UPDATED_BY]
			,[UPDATED_NAME]
			,[UPDATE_TIMESTAMP]
			,[ACCOUNT_ID]
			,[REALLO_DATE]
			,[CASE_ID]
			,[TRANSACTION_CHANGE_ID]
			,[DIVIDEND_CHOICE]
			,[CASH_ACCOUNT_ID]
			,[DR_SEG5]
			,[CR_SEG5]
			,[POLICY_YEAR]
			,[NEED_POSTED]
			,[DR_SEG9]
			,[DR_SEG10]
			,[DR_SEG11]
			,[DR_SEG12]
			,[DR_SEG13]
			,[DR_SEG14]
			,[DR_SEG15]
			,[DR_SEG16]
			,[DR_SEG17]
			,[DR_SEG18]
			,[DR_SEG19]
			,[DR_SEG20]
			,[CR_SEG9]
			,[CR_SEG10]
			,[CR_SEG11]
			,[CR_SEG12]
			,[CR_SEG13]
			,[CR_SEG14]
			,[CR_SEG15]
			,[CR_SEG16]
			,[CR_SEG17]
			,[CR_SEG18]
			,[CR_SEG19]
			,[CR_SEG20]
			,[ODS_CREATED_DATE]
			,[ODS_CREATED_BY]
			,[ODS_MODIFIED_DATE]
			,[ODS_MODIFIED_BY]
				)

	SELECT	[CAPITAL_DISTRIBUTE_ID]
			,[DISTRIBUTE_DATE]
			,[ITEM_ID]
			,[POLICY_ID]
			,[INSURED_ID]
			,[PRODUCT_ID]
			,[PRODUCT_NAME]
			,[DISTRIBUTE_AMOUNT]
			,[POSTED]
			,[INSERT_TIME]
			,[UPDATE_TIME]
			,[PREMIUM_ID]
			,[REALLOCATED]
			,[DISTRIBUTE_TYPE]
			,[CAPITAL_SOURCE]
			,[CAPITAL_CHANGE_ID]
			,[BONUS_ALLOCATION_METHOD]
			,[BONUS_SUM_ASSURED]
			,[ORIGIN_AMOUNT]
			,[ORIGIN_BONUS_SUM_ASSURED]
			,[CURRENCY_ID]
			,[CURRENCY_CODE]
			,[ORIG_CURRENCY_ID]
			,[CHARGE_TYPE_ID]
			,[CHARGE_TYPE_NAME]
			,[REVERSAL_ID]
			,[RELATED_ID]
			,[ACCOUNTING_DATE]
			,[JE_CREATOR_ID]
			,[JE_CREATOR__NAME]
			,[JE_POSTING_ID]
			,[DR_SEG1]
			,[DR_SEG2]
			,[DR_SEG3]
			,[DR_SEG4]
			,[DR_SEG6]
			,[DR_SEG7]
			,[DR_SEG8]
			,[CR_SEG1]
			,[CR_SEG2]
			,[CR_SEG3]
			,[CR_SEG4]
			,[CR_SEG6]
			,[CR_SEG7]
			,[CR_SEG8]
			,[ORGANIZATION_ID]
			,[AGENT_ID]
			,[ACCOUNT_TYPE_CODE]
			,[ACCOUNT_TYPE_NAME]
			,[INSERTED_BY]
			,[INSERTED_NAME]
			,[INSERT_TIMESTAMP]
			,[UPDATED_BY]
			,[UPDATED_NAME]
			,[UPDATE_TIMESTAMP]
			,[ACCOUNT_ID]
			,[REALLO_DATE]
			,[CASE_ID]
			,[TRANSACTION_CHANGE_ID]
			,[DIVIDEND_CHOICE]
			,[CASH_ACCOUNT_ID]
			,[DR_SEG5]
			,[CR_SEG5]
			,[POLICY_YEAR]
			,[NEED_POSTED]
			,[DR_SEG9]
			,[DR_SEG10]
			,[DR_SEG11]
			,[DR_SEG12]
			,[DR_SEG13]
			,[DR_SEG14]
			,[DR_SEG15]
			,[DR_SEG16]
			,[DR_SEG17]
			,[DR_SEG18]
			,[DR_SEG19]
			,[DR_SEG20]
			,[CR_SEG9]
			,[CR_SEG10]
			,[CR_SEG11]
			,[CR_SEG12]
			,[CR_SEG13]
			,[CR_SEG14]
			,[CR_SEG15]
			,[CR_SEG16]
			,[CR_SEG17]
			,[CR_SEG18]
			,[CR_SEG19]
			,[CR_SEG20]
			,GETDATE() AS [ODS_CREATED_DATE]
			,@modifier AS [ODS_CREATED_BY]
			,GETDATE() AS [ODS_MODIFIED_DATE]
			,@modifier AS [ODS_MODIFIED_BY]
	  FROM [SELIC_STAGING].[EBAO_LS].[STG_CAPITAL_DISTRIBUTE]
--	  where (SUBSTRING([FILE_NAME],(PATINDEX('%[0-9]%',[FILE_NAME])),8) = @latest_file_date)
--			and DOC_NBR Not Like '%Total%'
END

	END TRY  -------------------- END TRY
	BEGIN CATCH  
		SET @error_message = (SELECT ERROR_MESSAGE())
		SET @o_output = 1
		SELECT @error_message AS ERROR
	END CATCH  -------------------- END CATCH
END
GO

