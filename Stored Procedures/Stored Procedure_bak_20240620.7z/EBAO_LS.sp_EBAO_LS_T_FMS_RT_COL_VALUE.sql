USE [SELIC]
GO

/****** Object:  StoredProcedure [EBAO_LS].[sp_EBAO_LS_T_FMS_RT_COL_VALUE]    Script Date: 20/6/2567 14:02:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







---- =============================================
---- Author:		<Kannikar P.>
---- Create date:	<20-06-2024>
---- Description:	<EBAO LS T_FMS_RT_COL_VALUE>
---- =============================================
CREATE PROCEDURE [EBAO_LS].[sp_EBAO_LS_T_FMS_RT_COL_VALUE]
	@o_output int output
AS
BEGIN

BEGIN TRY -------------------- BEGIN TRY

	DECLARE @error_message NVARCHAR(MAX);

	DECLARE @modifier VARCHAR(50);
	SET @modifier = 'ITDM\KANNIKAR'


	DELETE FROM [EBAO_LS].[T_FMS_RT_COL_VALUE]
	WHERE EXISTS (SELECT 1 
				  FROM [SELIC_STAGING].[EBAO_LS].[STG_T_FMS_RT_COL_VALUE] r
				  WHERE r.[RT_COLUMN_ID] = [RT_COLUMN_ID])


	INSERT INTO [EBAO_LS].[T_FMS_RT_COL_VALUE]
		([COL_VALUE], [MIN_VALUE], [MAX_VALUE], [COL_VALUE_DESC], [COL_VALUE_ID], [RT_COLUMN_ID], [ODS_CREATED_DATE], [ODS_CREATED_BY], [ODS_MODIFIED_DATE], [ODS_MODIFIED_BY])
	SELECT 
		 [COL_VALUE], [MIN_VALUE], [MAX_VALUE], [COL_VALUE_DESC], [COL_VALUE_ID], [RT_COLUMN_ID], GETDATE(), @modifier, GETDATE(), @modifier
	FROM [SELIC_STAGING].[EBAO_LS].[STG_T_FMS_RT_COL_VALUE]


END TRY  -------------------- END TRY
BEGIN CATCH  
	SET @error_message = (SELECT ERROR_MESSAGE())
	SET @o_output = 1
	SELECT @error_message AS ERROR
END CATCH  -------------------- END CATCH

END

GO

